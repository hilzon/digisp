module.exports = {
    JWT_SECRET: 'babaauth'
};
