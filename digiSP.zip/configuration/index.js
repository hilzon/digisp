module.exports = {
    JWT_SECRET: 'baba'
};
